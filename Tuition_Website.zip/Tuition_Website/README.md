# Tuition-Management-System-using-PHP

#### This is a tuition management system that involved three users which are admin, teacher and student. The system provide a validation system for a teacher who want to join teaching in the tuition center. It provides a timetable function that will managed by admin, who can also add a new subject into the system. PHP and mySQL are used to develop the system.

![home](mj20.jpg)

![login](mj21.jpg)

![login](mj22.jpg)

![add subject](mj23.jpg)

![timetable](mj24.jpg)

![student detail](mj25.jpg)

